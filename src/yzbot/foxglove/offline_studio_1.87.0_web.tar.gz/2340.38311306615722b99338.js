"use strict";(self.webpackChunk=self.webpackChunk||[]).push([[2340],{32340:(E,n,e)=>{e.r(n),e.d(n,{default:()=>u});var s=e(97680);const u=s.ImagePanel}}]);

//# sourceMappingURL=2340.38311306615722b99338.js.map